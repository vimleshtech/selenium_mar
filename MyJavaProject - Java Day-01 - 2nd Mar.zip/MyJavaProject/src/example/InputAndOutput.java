package example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class InputAndOutput {

	public static void main(String[] a) throws IOException 
	{
	
		//output
		System.out.println("hi");
		System.out.print("nitin");
		
		System.out.print("Test");
		
		////
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		
		String name;
		int n;
		
		System.out.println("enter nu ");
		n = sc.nextInt();
		System.out.println(n);				
			
		System.out.println("enter name ");
		name = sc.next(); //this is = this 
		System.out.println(name);
		
		System.out.println("enter name ");		
		name = sc1.nextLine(); //this is  = this is 
		System.out.println(name);
		
				
		//BuffereReader
		BufferedReader br = 
				new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("enter name :");
		name  = br.readLine();
		System.out.println(name);
		
		System.out.println("enter nu. ");		
		n =Integer.parseInt( br.readLine());
		System.out.println(n);
		
		
	}

}
