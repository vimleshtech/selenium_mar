package example;

public class ArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[] = {1,1,55,1,2};
		//1 -3
		//55 -1
		//2 -1
		
		
		System.out.println(a.length);
		
		for(int n : a)//for each 
		{
			System.out.println(n);
		}
		
		//
		int n[][] = {{1,2,3},{44,55,3}};
		for(int d[] : n)
		{
			for(int j: d)
			{
				System.out.print(j+"\t");
			}
			System.out.println();
			
		}
	}

}
