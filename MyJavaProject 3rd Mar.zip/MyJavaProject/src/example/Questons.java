package example;

import java.util.Scanner;

public class Questons {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int s;
		
		System.out.println("enter size : ");
		s = sc.nextInt();
		
		int n[] = new int[s];
		
		for(int i=0; i<s;i++)
		{
			System.out.println("enter data : ");
			n[i] = sc.nextInt();			
		}
		
		//get unique item 
		int uq[] = new int[s];	
		int ind =0;
		
		for(int i=0; i<s;i++)
		{
			int f =0;
			
			for(int j=0;j<s;j++)
			{
					if(n[i] == uq[j])
					{
						f =1;
					}
			}
			
			if(f ==0)
			{
				uq[ind] = n[i];
				ind++;
			}
		}
		
		//print unique value
		for(int i=0; i<ind;i++)
		{
			System.out.println(uq[i]);
		}
		
		//count
		
		for(int i=0; i<ind;i++)
		{
			int c=0;
			for(int j=0; j<s;j++)
			{
				if(uq[i] == n[j])
					c++;
				
			}
			System.out.println("count of "+uq[i]+" is : "+c);
		}
		

	}

}
