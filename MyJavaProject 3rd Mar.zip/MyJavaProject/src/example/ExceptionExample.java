package example;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class ExceptionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc =new Scanner(System.in);
		int n,d,o;
		
		System.out.println("enter data ");
		
		n  = sc.nextInt();
		System.out.println("enter data ");
		
		d = sc.nextInt();
		
		int i=0;
		while(i<5)
		{
		try
		{
			
			if(d<0)
			{
				Exception e = new Exception("divisor cannot be less than 0");
				throw e;
			}
			o = n/d;
			System.out.println(o);
		}
		catch (ArithmeticException  e) {
			// TODO: handle exception
		}
		catch (ArrayIndexOutOfBoundsException e) {
			// TODO: handle exception
		}
		
		catch (Exception e) { //Exception must be at last 
			// TODO: handle exception
			System.out.println("there is technical error "+e);
		}
		 finally {
		
			 i++;
			 System.out.println("end of code");
		 }
		
		}
		o =n+d;
		System.out.println(o);
	}

}
