package example;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ThrowsEx {

	public static void main(String[] args)  {

		
		try
		{
		FileReader fr = new FileReader("C:\\\\Tech Vision\\Desktop\\sql.txt");
		
		}
		catch (Exception e) {
			System.out.println(e);
		}

	}

}
