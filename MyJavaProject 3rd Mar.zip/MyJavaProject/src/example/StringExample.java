package example;

import java.util.Scanner;

public class StringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc =new Scanner(System.in);
		
		String name;
		System.out.println("enter data :");
		
		name=sc.nextLine();
		
		String ns = name.toUpperCase();
		System.out.println(ns);
		
		
		ns = name.toLowerCase();
		System.out.println(ns);
		
		
		ns = name.replace("o", "xy");
		System.out.println(ns);
		
		
		ns = name.trim();
		System.out.println(ns);
		
		
		int l = name.length();
		System.out.println(l);
		
		
		int ps = name.indexOf("m");
		System.out.println(ps);
		
		char c = name.charAt(2);
		System.out.println(c);
		
		int nn = c; //convert to ascci 
		System.out.println(nn);
		
		
		ns= name.substring(2,5); //raman sinha = man
		System.out.println(ns);
		
		String s[] = name.split(" ");//raman,kumar,sinha ={raman,kumar , sinha}
		System.out.println(s[0]); //firsst name 
		
		
		String a,b,cc;
		a ="dd";
		b ="skhsh";
		cc =a+b;
		
		System.out.println(cc);
		cc=a.concat(b);
		System.out.println(cc);
		
		
		if(name.startsWith("a"))
		{
				System.out.println("start with a");
		}
		else
		{
			System.out.println("not start with a");
		}
		
		//
		if(name.endsWith("n"))
		{
				System.out.println("end with n");
		}
		else
		{
			System.out.println("not end with n");
		}
		
		//
		if(name.contains("ma")) //raman raman //ram a 
		{
				System.out.println("ma is match");
		}
		else
		{
			System.out.println("ma is not match");
		}
		
		//
		if(name.equals("test"))
		{
			System.out.println("test is match");
		}
		else
		{
			System.out.println("test is not match");
		}
		
		//
		if(name.equalsIgnoreCase("TEst"))
		{
			System.out.println("test is match - insensetive");
		}
		else
		{
			System.out.println("test is not match with insensetive");
		}
		
		
		
	}

}
