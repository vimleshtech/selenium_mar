package example;

import java.util.Scanner;

public class ProperCaseExample {

	public static void main(String[] args) {
		
		
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter string  ");
		String s = sc.nextLine();
		
		String str[] = s.split(" ");	
		String ww ="";
		for(String w : str)
		{
			 ww += 	w.substring(0,1).toUpperCase() + w.substring(1,w.length()).toLowerCase()+" ";
			
			
		}
		
		System.out.print(ww);
		
		

	}

}
